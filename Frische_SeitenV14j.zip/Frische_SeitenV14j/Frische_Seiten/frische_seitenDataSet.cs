﻿namespace Frische_Seiten
{


    partial class frische_seitenDataSet
    {
        partial class DichtDataTable
        {
        }
    }
}

namespace Frische_Seiten.frische_seitenDataSetTableAdapters {
    
    
    public partial class GlatzeTableAdapter {
    }
}
